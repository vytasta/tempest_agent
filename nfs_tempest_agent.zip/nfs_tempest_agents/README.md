# NFS & OpenStack Test Agent

> AI agents that run Connectathon NFS tests and OpenStack Tempest tests from a plain English prompt — parsing, comparing, and reporting results across versions, mounts, and configs.

**Author:** vytasta — [vytasta.github.io/uberzunn/agents.html](https://vytasta.github.io/uberzunn/agents.html)

![CI](https://github.com/vytasta/nfs_tempest_agent/actions/workflows/ci.yml/badge.svg)
![Python](https://img.shields.io/badge/python-3.9%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)

---

## Two agents in one project

### 1. Connectathon NFS Agent
Runs NFS Connectathon test suites (basic, general, special, lock) across multiple NFS versions (v3, v4, v4.1) or mount points and compares pass/fail results with regression detection.

### 2. OpenStack Tempest Agent
Runs OpenStack Tempest test groups (compute, network, storage, identity, image, object) across two environment configs (e.g. prod vs staging) and surfaces regressions, improvements, and failed test names.

---

## Example prompts

```python
# Connectathon
cthon_prompt = (
    "Run Connectathon NFS tests (basic, general, special, lock) "
    "on nfs-server-01:/exports/vol1 comparing NFSv3, NFSv4, and NFSv4.1."
)

# Tempest
tempest_prompt = (
    "Run OpenStack Tempest tests (compute, network, storage, identity, image) "
    "comparing prod (http://controller-prod:5000/v3) vs "
    "staging (http://controller-staging:5000/v3) with 4 concurrent workers."
)
```

---

## Sample output — Connectathon

```
CONNECTATHON NFS TEST REPORT
==============================
Version/Mount  | Overall | Passed | Failed | Skipped | Errors
---------------+---------+--------+--------+---------+-------
NFSv3          | PASS    | 32     | 0      | 0       | 0
NFSv4          | FAIL    | 31     | 1      | 0       | 0
NFSv4.1        | PASS    | 32     | 0      | 0       | 0

REGRESSIONS
-----------
  [special] NFSv3 → NFSv4: +1 failures (setuid/setgid — expected, root squash)

RECOMMENDATION
--------------
NFSv4.1 recommended for production. NFSv4 setuid failure is expected behaviour.
```

## Sample output — Tempest

```
OPENSTACK TEMPEST TEST REPORT
==============================
Config   | Overall | Pass% | Passed | Failed | Skipped | Duration
---------+---------+-------+--------+--------+---------+---------
prod     | FAIL    | 92.3% | 36     | 2      | 3       | 171.7s
staging  | FAIL    | 85.7% | 36     | 4      | 2       | 183.4s

REGRESSIONS (staging vs prod)
------------------------------
  [compute] +1 failure: test_attach_volume
  [storage] +1 failure: test_clone_volume

RECOMMENDATION
--------------
Do NOT promote staging. Investigate Cinder backend config and Nova-Cinder connectivity.
```

---

## Quick start

```bash
git clone https://github.com/vytasta/nfs_tempest_agent
cd nfs_tempest_agent
pip install -r requirements.txt

# Install connectathon
git clone https://github.com/linux-nfs/connectathon /opt/connectathon
cd /opt/connectathon && make

# Install tempest
pip install tempest

# Set API key
export GOOGLE_API_KEY="AIza..."

# Run
python nfs_tempest_agent.py
```

## Dry-run (no tools, no API key needed)

```bash
export DRY_RUN=true
python nfs_tempest_agent.py
```

---

## Project structure

```
nfs_tempest_agent/
├── nfs_tempest_agent.py        # main agent + LangGraph graphs
├── tools/
│   ├── __init__.py
│   ├── connectathon_tools.py   # generate / run / parse / compare NFS
│   └── tempest_tools.py        # generate / run / parse / compare Tempest
├── reports/                    # output JSON + text reports
├── requirements.txt
├── .env.example
├── .gitignore
└── .github/workflows/ci.yml
```

---

## Roadmap
- [ ] pynfs test suite support
- [ ] Tempest scenario tests (end-to-end)
- [ ] Multi-server NFS comparison (server A vs server B)
- [ ] HTML report with pass/fail charts
- [ ] Slack notification on regression detected

---

## License
MIT
