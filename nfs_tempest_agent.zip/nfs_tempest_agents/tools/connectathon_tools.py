"""
connectathon_tools.py
=====================
Tool definitions for the Connectathon NFS test agent.

Covers:
  - generate_connectathon_config  → build test run parameters
  - run_connectathon              → execute test suite on a mount/version
  - parse_connectathon_output     → extract pass/fail/skip per suite
  - compare_connectathon_results  → diff results across versions or mounts

Test suites:
  b = basic     : basic file operations (open, read, write, close, unlink)
  g = general   : general POSIX filesystem operations
  s = special   : special filesystem features (symlinks, hardlinks, rename)
  l = lock      : NFS locking (fcntl, flock, lockd)

Author : vytasta — https://vytasta.github.io/uberzunn/agents.html
"""

import json
import os
import re
import subprocess
import tempfile
from langchain_core.tools import tool

DRY_RUN = os.environ.get("DRY_RUN", "false").lower() == "true"

# Default path where connectathon is installed
CTHON_PATH = os.environ.get("CTHON_PATH", "/opt/connectathon")


# ─────────────────────────────────────────────────────────────
# TOOL 1: Generate test config
# ─────────────────────────────────────────────────────────────

@tool
def generate_connectathon_config(
    server: str,
    mount_point: str,
    nfs_version: str = "4",
    test_suites: str = "b,g,s,l",
    test_dir: str = "/mnt/nfstest",
    timeout_seconds: int = 300,
    nfs_options: str = "",
) -> str:
    """
    Generate a Connectathon NFS test configuration.

    Args:
        server:          NFS server hostname or IP e.g. nfs-server-01
        mount_point:     export path on server e.g. /exports/vol1
        nfs_version:     NFS version to test: 3, 4, 4.1, 4.2
        test_suites:     comma-separated suites: b=basic, g=general,
                         s=special, l=lock  e.g. "b,g,s,l"
        test_dir:        local directory to mount and run tests in
        timeout_seconds: max time per test suite
        nfs_options:     extra mount options e.g. "rsize=65536,wsize=65536"

    Returns:
        JSON string with the full test configuration.
    """
    if DRY_RUN:
        return json.dumps({
            "server":          server,
            "mount_point":     mount_point,
            "nfs_version":     nfs_version,
            "test_suites":     test_suites.split(","),
            "test_dir":        test_dir,
            "timeout_seconds": timeout_seconds,
            "nfs_options":     nfs_options,
            "mount_cmd":       f"[DRY-RUN] mount -t nfs -o vers={nfs_version}{','+nfs_options if nfs_options else ''} {server}:{mount_point} {test_dir}",
            "cthon_path":      CTHON_PATH,
            "dry_run":         True,
        })

    mount_opts = f"vers={nfs_version}"
    if nfs_options:
        mount_opts += f",{nfs_options}"

    mount_cmd = f"mount -t nfs -o {mount_opts} {server}:{mount_point} {test_dir}"

    return json.dumps({
        "server":          server,
        "mount_point":     mount_point,
        "nfs_version":     nfs_version,
        "test_suites":     test_suites.split(","),
        "test_dir":        test_dir,
        "timeout_seconds": timeout_seconds,
        "nfs_options":     nfs_options,
        "mount_cmd":       mount_cmd,
        "cthon_path":      CTHON_PATH,
        "dry_run":         False,
    })


# ─────────────────────────────────────────────────────────────
# TOOL 2: Run connectathon tests
# ─────────────────────────────────────────────────────────────

@tool
def run_connectathon(config_json: str) -> str:
    """
    Mount NFS and run Connectathon test suites based on config.

    Runs each suite (basic, general, special, lock) in sequence
    and captures stdout/stderr for parsing.

    Args:
        config_json: JSON string from generate_connectathon_config

    Returns:
        Raw output string from all test suites combined.
    """
    config = json.loads(config_json)

    if config.get("dry_run") or DRY_RUN:
        return _dry_run_connectathon_output(config)

    server      = config["server"]
    mount_point = config["mount_point"]
    nfs_version = config["nfs_version"]
    test_dir    = config["test_dir"]
    suites      = config["test_suites"]
    timeout     = config.get("timeout_seconds", 300)
    cthon_path  = config.get("cthon_path", CTHON_PATH)

    output_lines = []
    output_lines.append(f"=== Connectathon NFS Test Run ===")
    output_lines.append(f"Server  : {server}:{mount_point}")
    output_lines.append(f"Version : NFSv{nfs_version}")
    output_lines.append(f"Suites  : {', '.join(suites)}")
    output_lines.append("")

    try:
        # Create mount point if needed
        os.makedirs(test_dir, exist_ok=True)

        # Mount NFS
        mount_opts = f"vers={nfs_version}"
        if config.get("nfs_options"):
            mount_opts += f",{config['nfs_options']}"

        print(f"    [connectathon] mounting {server}:{mount_point} → {test_dir}")
        mount_result = subprocess.run(
            ["mount", "-t", "nfs", "-o", mount_opts,
             f"{server}:{mount_point}", test_dir],
            capture_output=True, text=True, timeout=30
        )

        if mount_result.returncode != 0:
            return json.dumps({"error": f"Mount failed: {mount_result.stderr}"})

        output_lines.append(f"Mount: SUCCESS ({server}:{mount_point} → {test_dir})")
        output_lines.append("")

        # Run each suite
        suite_map = {
            "b": ("basic",   f"{cthon_path}/basic/runtests"),
            "g": ("general", f"{cthon_path}/general/runtests"),
            "s": ("special", f"{cthon_path}/special/runtests"),
            "l": ("lock",    f"{cthon_path}/lock/runtests"),
        }

        for suite_key in suites:
            suite_key = suite_key.strip()
            if suite_key not in suite_map:
                continue
            suite_name, suite_bin = suite_map[suite_key]
            print(f"    [connectathon] running {suite_name} suite...")

            output_lines.append(f"=== Suite: {suite_name.upper()} ===")
            try:
                result = subprocess.run(
                    [suite_bin, "-N", test_dir],
                    capture_output=True, text=True,
                    timeout=timeout, cwd=test_dir
                )
                output_lines.append(result.stdout)
                if result.stderr:
                    output_lines.append(f"STDERR: {result.stderr}")
                output_lines.append(f"Exit code: {result.returncode}")
            except subprocess.TimeoutExpired:
                output_lines.append(f"TIMEOUT after {timeout}s")
            except FileNotFoundError:
                output_lines.append(
                    f"ERROR: {suite_bin} not found. "
                    f"Set CTHON_PATH env var to your connectathon install directory."
                )
            output_lines.append("")

        # Unmount
        subprocess.run(["umount", test_dir], capture_output=True, timeout=15)
        output_lines.append("Unmount: SUCCESS")

    except Exception as e:
        return json.dumps({"error": str(e)})

    return "\n".join(output_lines)


def _dry_run_connectathon_output(config: dict) -> str:
    """Simulate realistic connectathon output for dry-run mode."""
    server  = config.get("server", "nfs-server")
    version = config.get("nfs_version", "4")
    mount   = config.get("mount_point", "/exports/vol1")
    suites  = config.get("test_suites", ["b", "g", "s", "l"])

    suite_outputs = {
        "b": """=== Suite: BASIC ===
Test: open/close          PASSED
Test: read/write          PASSED
Test: mkdir/rmdir         PASSED
Test: rename              PASSED
Test: link/unlink         PASSED
Test: symlink             PASSED
Test: stat/chmod/chown    PASSED
Test: truncate            PASSED
BASIC: All 8 tests PASSED
Exit code: 0""",
        "g": """=== Suite: GENERAL ===
Test: file creation       PASSED
Test: large files         PASSED
Test: many files          PASSED
Test: file permissions    PASSED
Test: directory ops       PASSED
Test: concurrent access   PASSED
Test: seek operations     PASSED
Test: append writes       PASSED
Test: negative tests      PASSED
GENERAL: All 9 tests PASSED
Exit code: 0""",
        "s": """=== Suite: SPECIAL ===
Test: long filenames      PASSED
Test: special characters  PASSED
Test: deep directories    PASSED
Test: hardlinks           PASSED
Test: symlink chains      PASSED
Test: rename across dirs  PASSED
Test: sticky bit          PASSED
Test: setuid/setgid       FAILED  ← requires root on NFSv{version}
SPECIAL: 7 PASSED, 1 FAILED
Exit code: 1""".format(version=version),
        "l": """=== Suite: LOCK ===
Test: fcntl exclusive     PASSED
Test: fcntl shared        PASSED
Test: flock exclusive     PASSED
Test: flock shared        PASSED
Test: deadlock detection  PASSED
Test: lock upgrade        PASSED
Test: NLM recovery        PASSED
Test: byte-range locks    PASSED
LOCK: All 8 tests PASSED
Exit code: 0""",
    }

    lines = [
        f"=== Connectathon NFS Test Run [DRY-RUN] ===",
        f"Server  : {server}:{mount}",
        f"Version : NFSv{version}",
        f"Suites  : {', '.join(suites)}",
        f"Mount   : SUCCESS",
        "",
    ]

    for s in suites:
        s = s.strip()
        if s in suite_outputs:
            lines.append(suite_outputs[s])
            lines.append("")

    lines.append("Unmount: SUCCESS")
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────
# TOOL 3: Parse connectathon output
# ─────────────────────────────────────────────────────────────

@tool
def parse_connectathon_output(raw_output: str, label: str = "") -> str:
    """
    Parse Connectathon test output into structured pass/fail/skip counts.

    Args:
        raw_output: raw output string from run_connectathon
        label:      optional label e.g. "NFSv4" or "server-01/exports/vol1"

    Returns:
        JSON with per-suite pass/fail/skip counts and overall summary.
    """
    results = {
        "label":   label,
        "suites":  {},
        "total":   {"passed": 0, "failed": 0, "skipped": 0, "errors": 0},
        "overall": "UNKNOWN",
    }

    suite_name = None
    suite_map  = {
        "BASIC": "basic", "GENERAL": "general",
        "SPECIAL": "special", "LOCK": "lock",
    }

    for line in raw_output.splitlines():
        line = line.strip()

        # Detect suite header
        for key, name in suite_map.items():
            if f"Suite: {key}" in line or line.startswith(f"=== {key}"):
                suite_name = name
                results["suites"][suite_name] = {
                    "passed": 0, "failed": 0, "skipped": 0,
                    "errors": 0, "tests": []
                }
                break

        if not suite_name:
            continue

        suite = results["suites"][suite_name]

        # Count PASSED
        if "PASSED" in line and ":" in line:
            suite["passed"] += 1
            suite["tests"].append({"name": line.split(":")[0].strip(), "result": "PASSED"})

        # Count FAILED
        elif "FAILED" in line and ":" in line:
            suite["failed"] += 1
            suite["tests"].append({"name": line.split(":")[0].strip(), "result": "FAILED"})

        # Count SKIPPED
        elif "SKIPPED" in line and ":" in line:
            suite["skipped"] += 1
            suite["tests"].append({"name": line.split(":")[0].strip(), "result": "SKIPPED"})

        # Suite summary line e.g. "BASIC: All 8 tests PASSED"
        elif re.match(r"^(BASIC|GENERAL|SPECIAL|LOCK):", line):
            m = re.search(r"(\d+)\s+PASSED", line)
            if m and suite["passed"] == 0:
                suite["passed"] = int(m.group(1))
            m = re.search(r"(\d+)\s+FAILED", line)
            if m:
                suite["failed"] = int(m.group(1))

        # Errors
        elif "ERROR" in line or "TIMEOUT" in line:
            suite["errors"] += 1

    # Totals
    for s in results["suites"].values():
        results["total"]["passed"]  += s["passed"]
        results["total"]["failed"]  += s["failed"]
        results["total"]["skipped"] += s["skipped"]
        results["total"]["errors"]  += s["errors"]

    total = results["total"]
    if total["failed"] == 0 and total["errors"] == 0 and total["passed"] > 0:
        results["overall"] = "PASS"
    elif total["failed"] > 0 or total["errors"] > 0:
        results["overall"] = "FAIL"
    else:
        results["overall"] = "UNKNOWN"

    return json.dumps(results, indent=2)


# ─────────────────────────────────────────────────────────────
# TOOL 4: Compare results across versions / mounts
# ─────────────────────────────────────────────────────────────

@tool
def compare_connectathon_results(results_json_list: str) -> str:
    """
    Compare Connectathon results across multiple NFS versions or mounts.

    Args:
        results_json_list: JSON array of parsed result objects
                           (output from parse_connectathon_output)

    Returns:
        JSON comparison with regressions, improvements, and summary table.
    """
    try:
        results = json.loads(results_json_list)
    except Exception as e:
        return json.dumps({"error": f"Invalid JSON: {e}"})

    comparison = {
        "runs":        len(results),
        "labels":      [r.get("label", f"run-{i}") for i, r in enumerate(results)],
        "summary":     [],
        "regressions": [],
        "improvements":[],
        "suite_diff":  {},
    }

    # Summary table
    for r in results:
        total = r.get("total", {})
        comparison["summary"].append({
            "label":   r.get("label", "unknown"),
            "overall": r.get("overall", "UNKNOWN"),
            "passed":  total.get("passed", 0),
            "failed":  total.get("failed", 0),
            "skipped": total.get("skipped", 0),
            "errors":  total.get("errors", 0),
        })

    # Per-suite diff
    all_suites = set()
    for r in results:
        all_suites.update(r.get("suites", {}).keys())

    for suite in sorted(all_suites):
        suite_data = []
        for r in results:
            s = r.get("suites", {}).get(suite, {})
            suite_data.append({
                "label":   r.get("label", "unknown"),
                "passed":  s.get("passed", 0),
                "failed":  s.get("failed", 0),
                "skipped": s.get("skipped", 0),
            })
        comparison["suite_diff"][suite] = suite_data

    # Detect regressions and improvements (compare first run to others)
    if len(results) >= 2:
        baseline = results[0]
        for r in results[1:]:
            label = r.get("label", "unknown")
            for suite in all_suites:
                base_suite = baseline.get("suites", {}).get(suite, {})
                curr_suite = r.get("suites", {}).get(suite, {})
                base_fail  = base_suite.get("failed", 0)
                curr_fail  = curr_suite.get("failed", 0)

                if curr_fail > base_fail:
                    comparison["regressions"].append({
                        "suite":     suite,
                        "label":     label,
                        "baseline":  baseline.get("label"),
                        "base_fail": base_fail,
                        "curr_fail": curr_fail,
                        "delta":     curr_fail - base_fail,
                    })
                elif curr_fail < base_fail:
                    comparison["improvements"].append({
                        "suite":     suite,
                        "label":     label,
                        "baseline":  baseline.get("label"),
                        "base_fail": base_fail,
                        "curr_fail": curr_fail,
                        "delta":     base_fail - curr_fail,
                    })

    return json.dumps(comparison, indent=2)


# ── Export ────────────────────────────────────────────────────

CONNECTATHON_TOOLS = [
    generate_connectathon_config,
    run_connectathon,
    parse_connectathon_output,
    compare_connectathon_results,
]
