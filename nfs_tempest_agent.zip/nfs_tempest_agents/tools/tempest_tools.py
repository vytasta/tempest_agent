"""
tempest_tools.py
================
Tool definitions for the OpenStack Tempest test agent.

Covers:
  - generate_tempest_config   → build tempest.conf for an environment
  - run_tempest               → execute tempest test groups
  - parse_tempest_output      → extract pass/fail/skip/error per group
  - compare_tempest_results   → diff results across configs/environments

Test groups:
  compute   : nova API tests (instances, flavors, keypairs, security groups)
  network   : neutron API tests (networks, subnets, ports, routers, security groups)
  storage   : cinder API tests (volumes, snapshots, backups)
  identity  : keystone API tests (users, projects, roles, tokens)
  image     : glance API tests (images, image members)
  object    : swift API tests (containers, objects)

Author : vytasta — https://vytasta.github.io/uberzunn/agents.html
"""

import json
import os
import re
import subprocess
from langchain_core.tools import tool

DRY_RUN = os.environ.get("DRY_RUN", "false").lower() == "true"

TEMPEST_PATH = os.environ.get("TEMPEST_PATH", "/opt/tempest")


# ─────────────────────────────────────────────────────────────
# TOOL 1: Generate tempest config
# ─────────────────────────────────────────────────────────────

@tool
def generate_tempest_config(
    auth_url: str,
    username: str,
    password: str,
    project_name: str,
    region: str = "RegionOne",
    test_groups: str = "compute,network,storage,identity,image",
    config_label: str = "default",
    network_id: str = "",
    image_ref: str = "",
    flavor_ref: str = "1",
    volume_type: str = "",
    run_timeout: int = 600,
    concurrency: int = 4,
) -> str:
    """
    Generate a tempest.conf configuration for an OpenStack environment.

    Args:
        auth_url:      Keystone endpoint e.g. http://controller:5000/v3
        username:      OpenStack username
        password:      OpenStack password
        project_name:  OpenStack project/tenant name
        region:        OpenStack region e.g. RegionOne
        test_groups:   comma-separated groups: compute, network, storage,
                       identity, image, object
        config_label:  human label for this config e.g. "prod" or "staging"
        network_id:    existing network UUID for compute tests
        image_ref:     image UUID to use for instance tests
        flavor_ref:    flavor ID for instance tests (default: 1)
        volume_type:   Cinder volume type for storage tests
        run_timeout:   max seconds per test group
        concurrency:   parallel test workers

    Returns:
        JSON string with config details and tempest.conf content.
    """
    if DRY_RUN:
        return json.dumps({
            "label":        config_label,
            "auth_url":     auth_url,
            "username":     username,
            "project_name": project_name,
            "region":       region,
            "test_groups":  test_groups.split(","),
            "network_id":   network_id,
            "image_ref":    image_ref,
            "flavor_ref":   flavor_ref,
            "volume_type":  volume_type,
            "concurrency":  concurrency,
            "run_timeout":  run_timeout,
            "tempest_conf": "[DRY-RUN] tempest.conf generated",
            "dry_run":      True,
        })

    tempest_conf = f"""[DEFAULT]
log_file = tempest_{config_label}.log
log_dir = /tmp

[auth]
admin_username = {username}
admin_password = {password}
admin_project_name = {project_name}
admin_domain_name = Default
use_dynamic_credentials = true

[identity]
uri_v3 = {auth_url}
auth_version = v3
region = {region}

[compute]
region = {region}
image_ref = {image_ref}
image_ref_alt = {image_ref}
flavor_ref = {flavor_ref}
flavor_ref_alt = {flavor_ref}
{f'fixed_network_name = {network_id}' if network_id else ''}

[network]
public_network_id = {network_id}
floating_network_name = public

[volume]
region = {region}
{f'volume_type = {volume_type}' if volume_type else ''}
build_timeout = 300

[image]
region = {region}
http_image = http://download.cirros-cloud.net/0.5.2/cirros-0.5.2-x86_64-disk.img

[object-storage]
region = {region}

[scenario]
img_file = cirros-0.5.2-x86_64-disk.img

[validation]
run_validation = false

[oslo_concurrency]
lock_path = /tmp/tempest_locks_{config_label}
"""
    return json.dumps({
        "label":        config_label,
        "auth_url":     auth_url,
        "username":     username,
        "project_name": project_name,
        "region":       region,
        "test_groups":  test_groups.split(","),
        "network_id":   network_id,
        "image_ref":    image_ref,
        "flavor_ref":   flavor_ref,
        "volume_type":  volume_type,
        "concurrency":  concurrency,
        "run_timeout":  run_timeout,
        "tempest_conf": tempest_conf,
        "dry_run":      False,
    })


# ─────────────────────────────────────────────────────────────
# TOOL 2: Run tempest tests
# ─────────────────────────────────────────────────────────────

@tool
def run_tempest(config_json: str) -> str:
    """
    Write tempest.conf and run tempest test groups.

    Runs each group (compute, network, storage etc.) and captures
    full stestr/subunit output for parsing.

    Args:
        config_json: JSON string from generate_tempest_config

    Returns:
        Raw tempest output string.
    """
    config = json.loads(config_json)

    if config.get("dry_run") or DRY_RUN:
        return _dry_run_tempest_output(config)

    label        = config["label"]
    test_groups  = config["test_groups"]
    concurrency  = config.get("concurrency", 4)
    run_timeout  = config.get("run_timeout", 600)
    tempest_conf = config.get("tempest_conf", "")
    tempest_path = TEMPEST_PATH

    conf_path = f"/tmp/tempest_{label}.conf"
    with open(conf_path, "w") as f:
        f.write(tempest_conf)

    # Group → tempest test regex pattern
    group_patterns = {
        "compute":  "tempest.api.compute",
        "network":  "tempest.api.network",
        "storage":  "tempest.api.volume",
        "identity": "tempest.api.identity",
        "image":    "tempest.api.image",
        "object":   "tempest.api.object_storage",
    }

    output_lines = [
        f"=== OpenStack Tempest Test Run ===",
        f"Config  : {label}",
        f"Auth    : {config.get('auth_url')}",
        f"Groups  : {', '.join(test_groups)}",
        f"Workers : {concurrency}",
        "",
    ]

    for group in test_groups:
        group = group.strip()
        pattern = group_patterns.get(group)
        if not pattern:
            output_lines.append(f"WARNING: unknown group '{group}' — skipping")
            continue

        output_lines.append(f"=== Group: {group.upper()} ===")
        print(f"    [tempest] running {group} tests...")

        try:
            env = os.environ.copy()
            env["TEMPEST_CONFIG"] = conf_path

            result = subprocess.run(
                [
                    f"{tempest_path}/bin/tempest", "run",
                    "--regex", pattern,
                    "--concurrency", str(concurrency),
                    "--config-file", conf_path,
                ],
                capture_output=True, text=True,
                timeout=run_timeout, env=env,
                cwd=tempest_path,
            )
            output_lines.append(result.stdout)
            if result.stderr:
                output_lines.append(f"STDERR:\n{result.stderr[:500]}")
            output_lines.append(f"Exit code: {result.returncode}")
        except subprocess.TimeoutExpired:
            output_lines.append(f"TIMEOUT after {run_timeout}s")
        except FileNotFoundError:
            output_lines.append(
                f"ERROR: tempest not found at {tempest_path}. "
                "Set TEMPEST_PATH env var to your tempest install directory."
            )
        output_lines.append("")

    return "\n".join(output_lines)


def _dry_run_tempest_output(config: dict) -> str:
    """Simulate realistic tempest output for dry-run mode."""
    label  = config.get("label", "default")
    groups = config.get("test_groups", ["compute", "network", "storage"])

    group_outputs = {
        "compute": """=== Group: COMPUTE ===
tempest.api.compute.servers.test_create_server ... ok
tempest.api.compute.servers.test_delete_server ... ok
tempest.api.compute.servers.test_list_servers ... ok
tempest.api.compute.servers.test_server_actions ... ok
tempest.api.compute.flavors.test_list_flavors ... ok
tempest.api.compute.keypairs.test_keypairs ... ok
tempest.api.compute.security_groups.test_security_groups ... ok
tempest.api.compute.servers.test_server_metadata ... ok
tempest.api.compute.servers.test_attach_volume ... FAIL
tempest.api.compute.servers.test_resize_server ... SKIP

Ran 10 tests in 48.2s
FAILED (failures=1, skipped=1)
Exit code: 1""",

        "network": """=== Group: NETWORK ===
tempest.api.network.test_networks ... ok
tempest.api.network.test_subnets ... ok
tempest.api.network.test_ports ... ok
tempest.api.network.test_routers ... ok
tempest.api.network.test_security_groups ... ok
tempest.api.network.test_floating_ips ... ok
tempest.api.network.test_load_balancers ... ok
tempest.api.network.test_dns_records ... ok

Ran 8 tests in 32.1s
OK
Exit code: 0""",

        "storage": """=== Group: STORAGE ===
tempest.api.volume.test_volumes_list ... ok
tempest.api.volume.test_volumes_get ... ok
tempest.api.volume.test_volumes_create_delete ... ok
tempest.api.volume.test_snapshots ... ok
tempest.api.volume.test_backups ... ok
tempest.api.volume.test_volume_types ... ok
tempest.api.volume.test_attach_detach ... ok
tempest.api.volume.test_clone_volume ... FAIL

Ran 8 tests in 61.4s
FAILED (failures=1)
Exit code: 1""",

        "identity": """=== Group: IDENTITY ===
tempest.api.identity.test_users ... ok
tempest.api.identity.test_projects ... ok
tempest.api.identity.test_roles ... ok
tempest.api.identity.test_tokens ... ok
tempest.api.identity.test_domains ... ok
tempest.api.identity.test_groups ... ok

Ran 6 tests in 12.3s
OK
Exit code: 0""",

        "image": """=== Group: IMAGE ===
tempest.api.image.test_images_list ... ok
tempest.api.image.test_image_upload ... ok
tempest.api.image.test_image_download ... ok
tempest.api.image.test_image_members ... ok
tempest.api.image.test_image_tags ... ok

Ran 5 tests in 18.7s
OK
Exit code: 0""",

        "object": """=== Group: OBJECT ===
tempest.api.object_storage.test_containers ... ok
tempest.api.object_storage.test_objects ... ok
tempest.api.object_storage.test_bulk_operations ... ok
tempest.api.object_storage.test_account_quotas ... SKIP

Ran 4 tests in 9.2s
OK (skipped=1)
Exit code: 0""",
    }

    lines = [
        f"=== OpenStack Tempest Test Run [DRY-RUN] ===",
        f"Config  : {label}",
        f"Auth    : {config.get('auth_url', 'http://controller:5000/v3')}",
        f"Groups  : {', '.join(groups)}",
        f"Workers : {config.get('concurrency', 4)}",
        "",
    ]

    for g in groups:
        g = g.strip()
        lines.append(group_outputs.get(g, f"=== Group: {g.upper()} ===\nNo output available\n"))
        lines.append("")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────
# TOOL 3: Parse tempest output
# ─────────────────────────────────────────────────────────────

@tool
def parse_tempest_output(raw_output: str, label: str = "") -> str:
    """
    Parse Tempest output into structured pass/fail/skip/error counts.

    Args:
        raw_output: raw output string from run_tempest
        label:      optional label e.g. "prod-config" or "staging-config"

    Returns:
        JSON with per-group pass/fail/skip/error counts and overall summary.
    """
    results = {
        "label":   label,
        "groups":  {},
        "total":   {"passed": 0, "failed": 0, "skipped": 0, "errors": 0},
        "overall": "UNKNOWN",
        "duration_seconds": 0,
    }

    current_group = None
    group_map = {
        "COMPUTE": "compute", "NETWORK": "network",
        "STORAGE": "storage", "IDENTITY": "identity",
        "IMAGE": "image", "OBJECT": "object",
    }

    for line in raw_output.splitlines():
        line_stripped = line.strip()

        # Detect group header
        for key, name in group_map.items():
            if f"Group: {key}" in line_stripped:
                current_group = name
                results["groups"][current_group] = {
                    "passed": 0, "failed": 0,
                    "skipped": 0, "errors": 0,
                    "failed_tests": [], "duration": 0,
                }
                break

        if not current_group:
            continue

        grp = results["groups"][current_group]

        # Individual test results
        if line_stripped.endswith("... ok"):
            grp["passed"] += 1
        elif line_stripped.endswith("... FAIL") or "FAIL" in line_stripped and "... FAIL" in line_stripped:
            grp["failed"] += 1
            test_name = line_stripped.split("...")[0].strip()
            grp["failed_tests"].append(test_name)
        elif line_stripped.endswith("... SKIP") or line_stripped.endswith("... skip"):
            grp["skipped"] += 1
        elif line_stripped.endswith("... ERROR"):
            grp["errors"] += 1

        # Summary line: "Ran X tests in Ys"
        m = re.search(r"Ran (\d+) tests? in ([\d.]+)s", line_stripped)
        if m:
            grp["duration"] = float(m.group(2))
            results["duration_seconds"] += float(m.group(2))

        # Alternative count from FAILED line: "FAILED (failures=X, skipped=Y)"
        m = re.search(r"failures=(\d+)", line_stripped)
        if m and grp["failed"] == 0:
            grp["failed"] = int(m.group(1))
        m = re.search(r"skipped=(\d+)", line_stripped)
        if m and grp["skipped"] == 0:
            grp["skipped"] = int(m.group(1))

    # Totals
    for g in results["groups"].values():
        results["total"]["passed"]  += g["passed"]
        results["total"]["failed"]  += g["failed"]
        results["total"]["skipped"] += g["skipped"]
        results["total"]["errors"]  += g["errors"]

    total = results["total"]
    if total["failed"] == 0 and total["errors"] == 0 and total["passed"] > 0:
        results["overall"] = "PASS"
    elif total["failed"] > 0 or total["errors"] > 0:
        results["overall"] = "FAIL"

    results["pass_rate"] = round(
        total["passed"] / max(total["passed"] + total["failed"] + total["errors"], 1) * 100, 1
    )

    return json.dumps(results, indent=2)


# ─────────────────────────────────────────────────────────────
# TOOL 4: Compare tempest results across configs
# ─────────────────────────────────────────────────────────────

@tool
def compare_tempest_results(results_json_list: str) -> str:
    """
    Compare Tempest results across two or more OpenStack configs.

    Args:
        results_json_list: JSON array of parsed result objects
                           (output from parse_tempest_output)

    Returns:
        JSON comparison with regressions, improvements, pass rates, summary.
    """
    try:
        results = json.loads(results_json_list)
    except Exception as e:
        return json.dumps({"error": f"Invalid JSON: {e}"})

    comparison = {
        "runs":         len(results),
        "labels":       [r.get("label", f"run-{i}") for i, r in enumerate(results)],
        "summary":      [],
        "regressions":  [],
        "improvements": [],
        "group_diff":   {},
        "failed_tests": {},
    }

    # Summary per run
    for r in results:
        total = r.get("total", {})
        comparison["summary"].append({
            "label":     r.get("label", "unknown"),
            "overall":   r.get("overall", "UNKNOWN"),
            "pass_rate": r.get("pass_rate", 0),
            "passed":    total.get("passed", 0),
            "failed":    total.get("failed", 0),
            "skipped":   total.get("skipped", 0),
            "errors":    total.get("errors", 0),
            "duration":  round(r.get("duration_seconds", 0), 1),
        })

    # Per-group diff
    all_groups = set()
    for r in results:
        all_groups.update(r.get("groups", {}).keys())

    for group in sorted(all_groups):
        group_data = []
        for r in results:
            g = r.get("groups", {}).get(group, {})
            group_data.append({
                "label":   r.get("label", "unknown"),
                "passed":  g.get("passed", 0),
                "failed":  g.get("failed", 0),
                "skipped": g.get("skipped", 0),
                "errors":  g.get("errors", 0),
            })
        comparison["group_diff"][group] = group_data

    # Collect all failed tests per run
    for r in results:
        label = r.get("label", "unknown")
        failed = []
        for g in r.get("groups", {}).values():
            failed.extend(g.get("failed_tests", []))
        comparison["failed_tests"][label] = failed

    # Regressions and improvements vs baseline
    if len(results) >= 2:
        baseline = results[0]
        for r in results[1:]:
            label = r.get("label", "unknown")
            for group in all_groups:
                base_g = baseline.get("groups", {}).get(group, {})
                curr_g = r.get("groups", {}).get(group, {})
                base_fail = base_g.get("failed", 0)
                curr_fail = curr_g.get("failed", 0)

                if curr_fail > base_fail:
                    comparison["regressions"].append({
                        "group":     group,
                        "label":     label,
                        "baseline":  baseline.get("label"),
                        "base_fail": base_fail,
                        "curr_fail": curr_fail,
                        "delta":     curr_fail - base_fail,
                        "new_failures": [
                            t for t in curr_g.get("failed_tests", [])
                            if t not in base_g.get("failed_tests", [])
                        ],
                    })
                elif curr_fail < base_fail:
                    comparison["improvements"].append({
                        "group":    group,
                        "label":    label,
                        "baseline": baseline.get("label"),
                        "base_fail":base_fail,
                        "curr_fail":curr_fail,
                        "delta":    base_fail - curr_fail,
                    })

    return json.dumps(comparison, indent=2)


# ── Export ────────────────────────────────────────────────────

TEMPEST_TOOLS = [
    generate_tempest_config,
    run_tempest,
    parse_tempest_output,
    compare_tempest_results,
]
