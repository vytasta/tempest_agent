from .connectathon_tools import CONNECTATHON_TOOLS
from .tempest_tools import TEMPEST_TOOLS

ALL_TOOLS = CONNECTATHON_TOOLS + TEMPEST_TOOLS
TOOL_MAP  = {t.name: t for t in ALL_TOOLS}
